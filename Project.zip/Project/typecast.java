class typecast
{
public static void main(String args[])
{
int a=4,b=8,c=9,d,e;
double x=3.0,y=6.5,z,k;
d=c/a;
k=a+y;
e=a+(int)y;
z=(double)c/a;
System.out.println("k="+k+"and e="+e);
System.out.println("d="+d+"and z="+z);
}
