<?php
$servername = "localhost";
$dbname = "blog";
$username = "root";
$password = "";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$username = $_POST['username'];
$email = $_POST['email'];
$phonenumber = $_POST['phonenumber'];
$password = $_POST['password'];
$confirmpassword = $_POST['confirmpassword'];

// Prepare the SQL query
$stmt = $conn->prepare("INSERT INTO newstream (username, email, phonenumber, password, confirmpassword) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssss", $username, $email, $phonenumber, $password, $confirmpassword);

if ($stmt->execute()) {
    echo "Your record is registered successfully.";
} else {
    echo "Registration failed. Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
